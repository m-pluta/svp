#ifndef BOUND_H
#define BOUND_H

#include "matrix.h"

double lambda_1_squared(const Matrix Bs, const int dim);

#endif
